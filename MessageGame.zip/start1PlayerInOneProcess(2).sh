java -jar MessageGame.jar 1 4008 Jim Ignore message
read -p "Press enter to exit"