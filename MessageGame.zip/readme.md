Message Game
Test task

Getting Started
To start application chose one of two start type:
1. 1 player for 1 application
2. 2 player in 1 application

For 1 start type:
1. Copy MessageGame.jar and start2PlayersInSameProcess.sh to same directory.
2. Start start2PlayersInSameProcess.sh.
3. Check result.

For 1 start type:
1. Copy MessageGame.jar, start1PlayerInOneProcess(1).sh and start1PlayerInOneProcess(2).sh to same directory.
2. Start start1PlayerInOneProcess(1).sh
3. Start start1PlayerInOneProcess(2).sh
3. Check result.

Built With
Maven - Dependency Management

Authors
Dmitrii Abramov
