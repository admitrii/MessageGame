package com.game.abramov.communicator;

/**
 * The class describe 2 communicator mode.
 * A sender start communication.*/
public enum Mode {
    SENDER,
    RECEIVER
}
