package com.game.abramov.player;

/**
 * Class discribes 2 types of players.
 * The initiator starts conversation.*/
public enum Type {
    INITIATOR,
    NON_NITIATOR
}
