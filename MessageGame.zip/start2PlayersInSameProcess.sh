java -jar MessageGame.jar 2 4008 Bob Maria message
read -p "Press enter to exit"